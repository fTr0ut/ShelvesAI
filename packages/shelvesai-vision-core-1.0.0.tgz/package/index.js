const { createVisionService } = require('./lib/visionService');
const geminiDetector = require('./lib/geminiDetector');

module.exports = {
  createVisionService,
  ...geminiDetector,
};
