# Changelog

## 1.0.0

- Initial extraction of the versioned `@shelvesai/vision-core` product from the debugger backend.
- Added the headless `createVisionService(...).analyzeImage(...)` API.
- Kept `vision-crops` as the internal geometry and crop engine dependency.
- Replaced the repo-local `file:../vision-crops` dependency with a normal versioned dependency on `@shelvesai/vision-crops@1.0.0` for external handoff and installation.
