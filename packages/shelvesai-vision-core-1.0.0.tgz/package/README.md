# `@shelvesai/vision-core`

Headless product package for ShelvesAI item detection. This package owns the backend vision pipeline and returns structured detection results plus binary artifacts. It does not own HTTP routes, storage, URLs, or frontend rendering.

`vision-crops` remains the geometry and crop engine under the hood, but ShelvesAI should integrate only with `@shelvesai/vision-core`.

## Scope

`@shelvesai/vision-core` includes:

- image preparation and MIME normalization
- HEIC/HEIF to JPEG conversion before decode when needed
- Gemini prompt construction and response parsing
- shelf-type vision settings resolution
- region prefiltering
- dense-box refinement
- vertical and horizontal slice orchestration
- cross-slice and cross-region dedupe
- crop-conflict resolution
- prompt-usage aggregation
- annotated overlay rendering
- final detection crop artifact extraction

It does not include:

- Express or any other HTTP framework
- persistence for artifacts
- URL generation
- frontend UI
- long-term release storage

## Versioning

This package is versioned with SemVer.

- `PATCH`: bug fixes, no contract changes
- `MINOR`: backward-compatible additions
- `MAJOR`: breaking input/output/default changes

ShelvesAI should pin an exact version and upgrade intentionally.

## Install / Pack

Inside this repo, the product artifact is generated from [`package.json`](./package.json).

### Registry Install

If both packages are published to your registry:

```bash
npm install @shelvesai/vision-crops@1.0.0 @shelvesai/vision-core@1.0.0
```

`vision-core` should remain pinned to the exact `vision-crops` version it was released against.

### Tarball Handoff Install

If you are handing off artifacts directly instead of publishing:

```bash
cd vision-crops
npm pack

cd ../vision-core
npm pack
```

That produces two tarballs:

- `shelvesai-vision-crops-1.0.0.tgz`
- `shelvesai-vision-core-1.0.0.tgz`

Install both into the ShelvesAI repo:

```bash
npm install ./vendor/shelvesai-vision-crops-1.0.0.tgz ./vendor/shelvesai-vision-core-1.0.0.tgz
```

```bash
cd vision-core
npm pack
```

That produces the `vision-core` tarball delivered to ShelvesAI for a specific version.

## Exports

[`index.js`](./index.js) exports:

- `createVisionService`
- `createGeminiDetector`
- `resolveRuntimeConfig`

## Quick Start

```js
const {
  createGeminiDetector,
  createVisionService,
  resolveRuntimeConfig,
} = require('@shelvesai/vision-core');

const runtime = resolveRuntimeConfig(process.env);
const detector = createGeminiDetector(runtime);
const vision = createVisionService({ detector, logger: console });

const result = await vision.analyzeImage({
  image: {
    buffer: imageBuffer,
    mimeType: 'image/png',
    filename: 'scan.png',
  },
  item: 'Inception',
  shelfType: 'movies',
  processingMode: 'default',
  browserImageSize: { width: 1440, height: 900 },
  regionPrefilterMode: 'default',
  quadrilateralMode: 'default',
  cropConflictMode: 'default',
});
```

## Required Input

`analyzeImage(...)` requires:

```js
{
  image: {
    buffer: Buffer,
    mimeType?: string,
    filename?: string
  }
}
```

## Optional Input

```js
{
  item?: string | null,
  shelfType?: 'movies' | 'books' | 'toys' | 'bottles' | 'general',
  processingMode?: 'default' | 'vertical_slices',
  browserImageSize?: { width?: number, height?: number } | null,
  regionPrefilterMode?: 'default' | 'on' | 'off',
  quadrilateralMode?: 'default' | 'on' | 'off',
  cropConflictMode?: 'default' | 'on' | 'off'
}
```

Notes:

- `shelfType` must be supported by the detector instance.
- polygon shelf types are only available when polygon crops are enabled in the detector/runtime config.
- `vertical_slices` requires multi-region prefilter support on the detector and will return `422`-style errors if that prerequisite is missing.

## Output Contract

`analyzeImage(...)` returns:

```js
{
  modelUsed: string | null,
  request: {
    item: string | null,
    shelfType: string,
    filename: string | null,
    processingMode: 'default' | 'vertical_slices',
    quadrilateralMode: 'default' | 'on' | 'off',
    cropConflictMode: 'default' | 'on' | 'off'
  },
  metadata: {
    mimeType: string,
    uploadMimeType: string | null,
    byteSize: number,
    format: string | null,
    convertedFromHeif: boolean,
    width: number,
    height: number,
    orientation: number | null,
    browserWidth: number | null,
    browserHeight: number | null,
    regionPrefilter: object,
    quadrilateralCrops: object,
    cropConflictResolution: object,
    polygonCrops: object,
    processing: object,
    promptTokenUsage: object,
    denseBoxRefinement: object | null,
    visionSettingsType: string | null,
    visionSettings: object | null
  },
  detections: [
    {
      label?: string | null,
      title?: string | null,
      author?: string | null,
      manufacturer?: string | null,
      confidence?: number | null,
      extractionIndex?: number | null,
      box2d: [number, number, number, number],
      quad2d?: Array<[number, number]> | null,
      polygon2d?: Array<[number, number]> | null,
      pixelRect: {
        left: number,
        top: number,
        width: number,
        height: number
      },
      cropArtifactIndex: number | null,
      cropWidth: number | null,
      cropHeight: number | null,
      cropContentType: string | null,
      cropSource: {
        kind: string,
        regionIndex: number | null,
        sliceId: number | null,
        width: number,
        height: number
      } | null
    }
  ],
  invalidDetections: array,
  warnings: string[],
  rawGeminiText: string,
  artifacts: {
    annotatedImage: {
      buffer: Buffer,
      contentType: 'image/png'
    },
    detectionCrops: Array<{
      buffer: Buffer,
      contentType: string,
      width: number,
      height: number
    } | null>
  }
}
```

Important:

- the core package never returns URLs
- `cropArtifactIndex` maps a detection to `artifacts.detectionCrops[index]`
- hosts are responsible for persisting buffers and generating any public or private URLs

## Host Responsibilities

ShelvesAI must provide:

- image bytes as a `Buffer`
- a detector instance, usually from `createGeminiDetector(...)`
- artifact persistence for `annotatedImage.buffer` and `detectionCrops[*].buffer`
- any URL generation layered on top of persisted artifacts
- application logging
- deployment-time environment variables

ShelvesAI may optionally provide:

- a custom `cropExtractor`
- a custom `visionSettingsResolver`
- a custom logger

## Default Gemini Runtime Config

Use `resolveRuntimeConfig(process.env)` to read:

- `GOOGLE_API_KEY` or `GEMINI_API_KEY`
- `GEMINI_MODEL`
- `GEMINI_THINKING_BUDGET`
- `GEMINI_MAX_OUTPUT_TOKENS`
- `GEMINI_DENSE_BOX_REFINEMENT_ENABLED`
- `GEMINI_DENSE_BOX_REFINEMENT_MODE`
- `GEMINI_DENSE_BOX_REFINEMENT_THRESHOLD`
- `GEMINI_DENSE_BOX_REFINEMENT_BATCH_SIZE`
- `GEMINI_DENSE_BOX_REFINEMENT_THINKING_BUDGET`
- `GEMINI_DENSE_BOX_REFINEMENT_MAX_OUTPUT_TOKENS`
- `GEMINI_REGION_PREFILTER_ENABLED`
- `GEMINI_REGION_PREFILTER_PADDING_X_PX`
- `GEMINI_REGION_PREFILTER_PADDING_Y_PX`
- `GEMINI_REGION_PREFILTER_THINKING_BUDGET`
- `GEMINI_QUADRILATERAL_CROPS_ENABLED`
- `GEMINI_POLYGON_CROPS_ENABLED`
- `GEMINI_CROP_CONFLICT_RESOLUTION_ENABLED`

## Geometry / Crop Behavior

- default crops are JPEG axis-aligned box crops
- quadrilateral crops return transparent PNG artifacts when a valid `quad2d` is available and the mode is enabled
- polygon crops return transparent PNG artifacts when a valid `polygon2d` is available and the shelf type resolves to polygon geometry
- when higher-order geometry is missing or unusable, the pipeline falls back to box crop extraction

## Integration Pattern For ShelvesAI

Typical host flow:

1. Read bytes from the uploaded image.
2. Call `vision.analyzeImage(...)`.
3. Persist `result.artifacts.annotatedImage.buffer`.
4. Persist each non-null `result.artifacts.detectionCrops[index].buffer`.
5. Map each detection's `cropArtifactIndex` into a host-owned artifact identifier or URL.
6. Store or return the remaining metadata and detections as normal application data.

## Release Workflow

For a new delivery to ShelvesAI:

1. Update code in this repo.
2. Bump `vision-crops` only if its public/exported behavior changed.
3. Bump `vision-core` for every delivered release.
4. Update both changelogs as needed.
5. Pack tarballs or publish exact versions.
6. Upgrade ShelvesAI by changing the pinned package versions intentionally.

## Debugger Relationship

[`vision-debugger`](../vision-debugger/README.md) is now a reference adapter over this package. It is the regression harness and local validation surface, not the reusable product contract.

## Release Notes

Versioned package changes are tracked in [`CHANGELOG.md`](./CHANGELOG.md). Each release note should state whether the change is:

- bug fix only
- backward-compatible addition
- breaking change
