# `@shelvesai/vision-crops`

Low-level geometry and crop extraction package used by `@shelvesai/vision-core`.

ShelvesAI should generally integrate with `@shelvesai/vision-core`, not this package directly. This package exists so `vision-core` can ship with a stable, versioned crop/math dependency instead of a repo-local file reference.

## What It Owns

- normalized box, quadrilateral, and polygon geometry handling
- remap helpers across crop and slice coordinate spaces
- crop rectangle math
- JPEG axis-aligned crop extraction
- transparent PNG quadrilateral and polygon crop extraction

## Exports

[`index.js`](./index.js) exports the geometry helpers from [`lib/visionBox2d.js`](./lib/visionBox2d.js), the crop extraction helpers from [`lib/visionCropper.js`](./lib/visionCropper.js), and `createVisionCropService` from [`lib/service.js`](./lib/service.js).

## Release Use

When handing off `vision-core` without a registry, ship both tarballs:

```bash
cd vision-crops
npm pack

cd ../vision-core
npm pack
```

Then install both exact versions in the ShelvesAI repo.

## Versioning

This package follows SemVer and is intended to stay compatible with the matching `vision-core` release that depends on it.
