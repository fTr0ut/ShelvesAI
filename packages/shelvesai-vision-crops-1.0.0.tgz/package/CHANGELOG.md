# Changelog

## 1.0.0

- Initial packaged release of the `@shelvesai/vision-crops` geometry and crop engine.
- Supports normalized box, quadrilateral, and polygon geometry helpers plus crop extraction for `vision-core`.
